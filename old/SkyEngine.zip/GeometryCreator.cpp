#include "stdafx.h"
#include "GeometryCreator.h"
#include "DirectXMesh.h"

using namespace DirectX;

namespace sky
{
	GeometryCreator::GeometryCreator(ShaderManager* shaderManager)
		:m_shaderManager(shaderManager)
	{
	}

	GeometryCreator::~GeometryCreator()
	{
		for (set<StaticMesh*>::const_iterator it = m_meshes.begin(); it != m_meshes.end(); ++it)
		{
			StaticMesh *mesh = (*it);
			if (mesh)
			{
				delete mesh;
				mesh = nullptr;
			}
		}
	}

	TerrainMesh *GeometryCreator::createTerrainMesh(const char* heightMapFile, int terrainHeight, int terrainWidth)
	{
		string filename(heightMapFile);

		size_t i = filename.rfind('.', filename.length());
		string ext = filename.substr(i + 1, filename.length() - i);

		TerrainMesh* mesh = new TerrainMesh(terrainHeight, terrainWidth);
		if (ext == "bmp")
		{
			assert(mesh->loadHeightMapsFromBitmap(heightMapFile));
		}

		if (ext == "r16")
		{
			assert(mesh->loadHeightMapsFromRaw(heightMapFile));
		}

		mesh->createMesh();

		IMaterial *baseMaterial = new Material();
		baseMaterial->setTextureCount(2);

		mesh->setMaterial(0, baseMaterial);


		return mesh;
	}

	StaticMesh *GeometryCreator::createSkydomeMesh()
	{
		vector<VertexPositionNormalTexture> verticess;
		vector<uint16_t> indices;

		GeometricPrimitive::CreateGeoSphere(verticess, indices, 5.0f, 2, false);

		vector<StaticMeshVertex> formatedVertices(verticess.size());
		vector<unsigned int> formatedindices(indices.size());

		for (size_t i = 0; i < formatedVertices.size(); i++)
		{
			formatedVertices[i].position = verticess[i].position;
			formatedVertices[i].normal = verticess[i].normal;
			formatedVertices[i].UVs = verticess[i].textureCoordinate;
		}

		for (size_t i = 0; i < formatedindices.size(); i++)
		{
			formatedindices[i] = static_cast<unsigned int>(indices[i]);
		}

		StaticMesh *mesh = initStaticMesh(formatedVertices, formatedindices, false, false);

		mesh->getMaterial(0)->setVertexShader(EVertexShader::VS_SKYBOX);
		mesh->getMaterial(0)->setPixelShader(EPixelShader::PS_SKYBOX);

		return mesh;
	}

	StaticMesh *GeometryCreator::initStaticMesh(vector<StaticMeshVertex>& verticess, vector<unsigned int>& indices, bool cullBackface, bool zBufferEnabled)
	{
		const size_t posCount = verticess.size();

		XMFLOAT3 *positions = new XMFLOAT3[posCount];
		XMFLOAT3 *normals = new XMFLOAT3[posCount];
		XMFLOAT2 *textcoods = new XMFLOAT2[posCount];
		XMFLOAT3 *tangents = new XMFLOAT3[posCount];
		XMFLOAT3 *binormals = new XMFLOAT3[posCount];

		for (size_t i = 0; i < verticess.size(); i++)
		{
			positions[i] = verticess[i].position;
			normals[i] = verticess[i].normal;
			textcoods[i] = verticess[i].UVs;
		}

		size_t numfaces = verticess.size() / 3;

		HRESULT res = ComputeTangentFrame(indices.data(), numfaces, positions, normals, textcoods, posCount, tangents, binormals);

		for (size_t i = 0; i < posCount; i++)
		{
			verticess[i].normal = normals[i];
			verticess[i].tangent = tangents[i];
			verticess[i].binormal = binormals[i];
		}

		if (positions)
		{
			delete positions;
			positions = nullptr;
		}

		if (normals)
		{
			delete normals;
			normals = nullptr;
		}

		if (textcoods)
		{
			delete textcoods;
			textcoods = nullptr;
		}

		if (tangents)
		{
			delete tangents;
			tangents = nullptr;
		}

		if (binormals)
		{
			delete binormals;
			binormals = nullptr;
		}

		StaticMeshVertexBuffer *VertexBuffer = new StaticMeshVertexBuffer();
		VertexBuffer->init(verticess);

		StaticIndexBuffer *indices_buffer = new StaticIndexBuffer();
		indices_buffer->init(indices);

		StaticMeshResources *meshResources = new StaticMeshResources(VertexBuffer, indices_buffer);

		StaticMesh *mesh = new StaticMesh();

		IVertexShader *vertexShader = m_shaderManager->getVertexShader(EVertexShader::VS_BASE);

		IPixelShader *pixelShader = m_shaderManager->getPixelShader(EPixelShader::PS_BASE);

		mesh->getRenderData()->setBackfaceCulling(cullBackface);

		mesh->getRenderData()->setZBufferEnabled(zBufferEnabled);

		mesh->getRenderData()->setResources(meshResources, vertexShader, pixelShader);

		mesh->setMaterialsCount(1);

		IMaterial *baseMaterial = new Material();
		baseMaterial->setTextureCount(pixelShader->getShaderResourceCount());

		mesh->setMaterial(0, baseMaterial);

		m_meshes.insert(mesh);

		return mesh;
	}

	StaticMesh *GeometryCreator::initStaticMesh(StaticMeshRenderData *renderData)
	{
		assert(renderData != nullptr);

		StaticMesh *mesh = new StaticMesh(renderData);

		mesh->setMaterialsCount(1);

		IPixelShader *pixelShader = renderData->getPipelineState()->getPSStageData()->getPixelShader();

		IMaterial *baseMaterial = new Material();
		baseMaterial->setTextureCount(pixelShader->getShaderResourceCount());

		mesh->setMaterial(0, baseMaterial);

		m_meshes.insert(mesh);

		return mesh;
	}
}
