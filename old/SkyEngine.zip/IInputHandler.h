#pragma once
#include "common.h"
#include "ICommand.h"

namespace sky
{
	class IInputHandler
	{
	public:
		virtual ~ IInputHandler() {}
	};
}