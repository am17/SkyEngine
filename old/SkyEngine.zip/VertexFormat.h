#pragma once
#include <DirectXMath.h>

using namespace DirectX;

namespace render
{
	struct InstanceType
	{
		XMFLOAT3 position;
	};

	struct StaticMeshVertex
	{
		StaticMeshVertex(){}
		StaticMeshVertex(XMFLOAT3 position, XMFLOAT3 normal, XMFLOAT2 UVs)
			:position(position), normal(normal), UVs(UVs){}

		XMFLOAT3 position;
		XMFLOAT3 normal;
		XMFLOAT3 tangent;
		XMFLOAT3 binormal;
		XMFLOAT2 UVs;
		XMFLOAT4 color;
	};
}