#pragma once
#include "IAPIBuffer.h"
#include <vector>
#include "VertexFormat.h"
#include "VertexInputLayout.h"

using namespace std;
using namespace render;

namespace sky
{
	class VertexBuffer
	{
	public:
		VertexBuffer();
		virtual ~VertexBuffer();
		IAPIBuffer *getAPIVertexBuffer() const;
	protected:
		IAPIBuffer *m_APIVertexBuffer;
	};

	class StaticMeshVertexBuffer : public VertexBuffer
	{
	public:
		StaticMeshVertexBuffer();
		~StaticMeshVertexBuffer();
		void init(const vector<StaticMeshVertex> & vertices);
		unsigned int getStride() const;
		unsigned int getVerticesCount() const;
		const void* getRawData() const;
	private:
		void* rawData;
		unsigned int m_stride;
		unsigned int m_numVertices;
	};
}

