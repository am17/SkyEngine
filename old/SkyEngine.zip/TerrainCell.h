#pragma once
#include <vector>
#include "VertexFormat.h"
#include "StaticMeshRenderData.h"
#include "DirectXCollision.h"

using namespace DirectX;
using namespace std;
using namespace render;

namespace sky
{
	class TerrainCell
	{
	public:
		TerrainCell();
		~TerrainCell();
		bool init(vector<StaticMeshVertex>& verticess, size_t i, size_t j, size_t cellHeight, size_t cellWidth, int m_terrainWidth);
		StaticMeshRenderData *getRenderData() const;
		void isVisible(bool visible);
		bool isVisible() const;
		const BoundingBox *getBoundingBox() const;
	private:
		StaticMeshRenderData *renderData;
		size_t m_vertexCount;
		size_t m_indexCount;
		BoundingBox m_AABB;
		bool m_visible;
	};
}

