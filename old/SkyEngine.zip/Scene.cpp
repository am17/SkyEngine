#include "stdafx.h"
#include "Scene.h"
#include "Camera.h"
#include "Entity.h"
#include "Log.h"

namespace scene
{
	Scene::Scene()
		: m_render(nullptr),
		m_camera(nullptr),
		m_entityFactory(nullptr),
		m_skyDomeEntity(nullptr),
		cbPerFrame(nullptr), 
		cbCamera(nullptr)
		//testText(nullptr)
	{
	}

	Scene::~Scene()
	{
		if (cbCamera)
		{
			delete cbCamera;
			cbCamera = nullptr;
		}

		if (cbPerFrame)
		{
			delete cbPerFrame;
			cbPerFrame = nullptr;
		}

		for (vector<Entity*>::const_iterator it = sceneStaticEntities.begin(); it != sceneStaticEntities.end(); ++it) 
		{
			Entity *entity = (*it);
			if (entity)
			{
				delete entity;
				entity = nullptr;
			}
		}
		sceneStaticEntities.clear();

		if (m_entityFactory)
		{
			delete m_entityFactory;
			m_entityFactory = nullptr;
		}
		
		if (m_camera)
		{
			delete m_camera;
			m_camera = nullptr;
		}
	}

	bool Scene::init(Render *render)
	{
		m_render = render;

		m_entityFactory = new EntityFactory(m_render->getDevice(), m_render->getShaderManager());

		m_camera = new Camera();
		if (!m_camera)
		{
			return false;
		}

		m_camera->setPosition(0.0f, 2.0f, -10.0f);

		cbPerFrame = new CBPerFrame();

		cbPerFrame->directionalLight.ambientColor = XMFLOAT4(0.15f, 0.15f, 0.15f, 1.0f);
		cbPerFrame->directionalLight.diffuseColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		//cbPerFrame->directionalLight.lightDirection = XMFLOAT3(0.0f, 0.0f, 1.0f);
		cbPerFrame->directionalLight.lightDirection = XMFLOAT3(0.0f, -1.0f, 0.0f);
		cbPerFrame->directionalLight.specularPower = 32.0f;
		cbPerFrame->directionalLight.specularColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);

		/*cbPerFrame->pointLight.ambientColor = XMFLOAT4(0.15f, 0.15f, 0.15f, 1.0f);
		cbPerFrame->pointLight.diffuseColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		cbPerFrame->pointLight.position = XMFLOAT3(0.0f, 0.0f, 1.0f);
		cbPerFrame->pointLight.specularPower = 32.0f;
		cbPerFrame->pointLight.specularColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		cbPerFrame->pointLight.range = 100.0f;
		cbPerFrame->pointLight.attenuation = XMFLOAT3(0.0f, 0.2f, 0.0f);*/

		//������ ������� ������� (��� ������� ����������� ����� �� ������ ������-�����)
		XMVECTOR lightDirection = XMLoadFloat3(&cbPerFrame->directionalLight.lightDirection);
		//XMVECTOR lightDirection = XMLoadFloat3(&cbPerFrame->pointLight.position);
		XMFLOAT3 camPos = m_camera->getPosition();
		XMVECTOR viewDirection = XMLoadFloat3(&camPos);
		XMVECTOR directionToLight = -lightDirection;
		XMVECTOR halfWayVector = XMVector3Normalize(directionToLight + viewDirection);
		XMStoreFloat3(&cbPerFrame->directionalLight.halfWayVector, halfWayVector);
		//XMStoreFloat3(&cbPerFrame->pointLight.halfWayVector, halfWayVector);

		cbCamera = new SCameraBuffer();
		cbCamera->cameraPosition = m_camera->getPosition();
		cbCamera->padding = 0.0f;
		cbCamera->reflectionMatrix = m_camera->getViewMatrix();
		cbCamera->projection = m_render->getProjectMatrix();

		m_camera->setProjectionMatrix(m_render->getProjectMatrix());

		//testText = new RenderTexture(800, 600);

		return true;
	}

	void Scene::update()
	{
		static float textureTranslation = 0.0f;
		textureTranslation += 0.00005f;
		if (textureTranslation > 1.0f)
		{
			textureTranslation -= 1.0f;
		}

		cbPerFrame->directionalLight.textureTranslation = textureTranslation;

		//printf("%f\n", elapsed);

		/*Timer *timer = m_render->getTimer();
		double currentTime = timer->getCurrentTime();
		double lastTime = timer->getLastTime();
		double elapsed = currentTime - lastTime;*/

		m_camera->update();

		/*XMFLOAT3 CP = m_camera->getPosition();

		printf("%f %f %f\n", CP.x,CP.y, CP.z);*/

		updateSkyDome();

		updateTerrain();
		
		updateStatic();
	}

	bool Scene::draw()
	{
		m_render->beginScene();

		drawSkyDome();

		drawTerrain();

		drawStatic();

		m_render->endScene();

		return true;
	}

	Entity* Scene::addEntity(EBASIC_ENTITY entityType)
	{
		Entity* Entity = nullptr;

		switch (entityType)
		{
		case sky::EBASIC_ENTITY::ENTITY_CUBE:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_CUBE>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_TEAPOT:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_TEAPOT>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_SPHERE:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_SPHERE>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_BOX:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_BOX>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_GEOSPHERE:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_GEOSPHERE>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_CYLINDER:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_CYLINDER>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_CONE:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_CONE>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_TORUS:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_TORUS>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_TETRAHEDRON:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_TETRAHEDRON>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_OCTAHEDRON:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_OCTAHEDRON>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_DODECAHEDRON:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_DODECAHEDRON>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_ICOSAHEDRON:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_ICOSAHEDRON>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_PLANE:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_PLANE>();
			break;
		case sky::EBASIC_ENTITY::ENTITY_TRIANGLE:
			Entity = m_entityFactory->create<EBASIC_ENTITY::ENTITY_TRIANGLE>();
		default:
			break;
		}

		assert(Entity != nullptr);

		sceneStaticEntities.push_back(Entity);

		return Entity;
	}

	TerrainEntity* Scene::addTerrainEntity(const char* heightMapFile, int terrainHeight, int terrainWidth)
	{
		TerrainEntity* Entity = m_entityFactory->createTerrainEntity(heightMapFile, terrainHeight, terrainWidth);

		assert(Entity != nullptr);

		sceneTerrainEntities.push_back(Entity);

		return Entity;
	}

	Entity* Scene::addSky()
	{
		Entity* Entity = m_entityFactory->createSkydomeEntity();

		assert(Entity != nullptr);

		m_skyDomeEntity = Entity;

		return Entity;
	}

	ICamera* Scene::getCamera() const
	{
		assert(m_camera != nullptr);

		return m_camera;
	}

	void Scene::renderToTexture(IRenderTargetResources *renderTargetResources)
	{
		m_render->getDevice()->setRenderTarget(renderTargetResources);

		m_render->getDevice()->clearRenderTarget(renderTargetResources);

		m_camera->updateReflectViewMatrix(-1.5f);

		Entity *entity = sceneStaticEntities[0];
		if (entity)
		{
			entity->update(m_camera->getReflectionViewMatrix(), m_render->getProjectMatrix());

			StaticMeshRenderData *renderData = entity->getMesh()->getRenderData();

			m_render->bindRenderData(renderData);
		}

		entity = sceneStaticEntities[1];
		if (entity)
		{
			entity->update(m_camera->getReflectionViewMatrix(), m_render->getProjectMatrix());

			StaticMeshRenderData *renderData = entity->getMesh()->getRenderData();

			m_render->bindRenderData(renderData);
		}

		m_render->getDevice()->resetRenderTarget();
	}

	void Scene::drawSkyDome()
	{
		if (m_skyDomeEntity)
		{
			StaticMeshRenderData *renderData = m_skyDomeEntity->getMesh()->getRenderData();

			m_render->bindRenderData(renderData);
		}
	}

	void Scene::drawTerrain()
	{
		for (vector<TerrainEntity*>::const_iterator it = sceneTerrainEntities.begin(); it != sceneTerrainEntities.end(); ++it)
		{
			TerrainEntity *entity = (*it);
			if (entity)
			{
				TerrainMesh* mesh = entity->getMesh();
				size_t cellsCount = mesh->getCellsCount();

				for (size_t i = 0; i < cellsCount; i++)
				{
					TerrainCell* cell = mesh->getCell(i);

					if (cell->isVisible())
					{
						m_render->bindRenderData(cell->getRenderData());
					}
				}
			}
		}
	}

	void Scene::drawStatic()
	{
		for (vector<Entity*>::const_iterator it = sceneStaticEntities.begin(); it != sceneStaticEntities.end(); ++it)
		{
			Entity *entity = (*it);
			if (entity)
			{
				StaticMeshRenderData *renderData = entity->getMesh()->getRenderData();

				m_render->bindRenderData(renderData);
			}
		}
	}

	void Scene::updateSkyDome()
	{
		if (m_skyDomeEntity)
		{
			m_skyDomeEntity->update(m_camera->getViewMatrix(), m_render->getProjectMatrix());

			XMFLOAT3 capPos = m_camera->getPosition();

			m_skyDomeEntity->setPosition(capPos.x, capPos.y, capPos.z);

			CBPerObject *cbPerObject = m_skyDomeEntity->getTransform();
			m_skyDomeEntity->getMesh()->getRenderData()->updateConstantBuffer<EShaderType::ST_Vertex>(0, cbPerObject);
			m_skyDomeEntity->getMesh()->getRenderData()->updateConstantBuffer<EShaderType::ST_Vertex>(1, cbCamera);
		}
	}
	void Scene::updateTerrain()
	{
		for (vector<TerrainEntity*>::const_iterator it = sceneTerrainEntities.begin(); it != sceneTerrainEntities.end(); ++it)
		{
			TerrainEntity *entity = (*it);
			if (entity)
			{
				entity->update(m_camera->getViewMatrix(), m_render->getProjectMatrix());

				CBPerObject *cbPerObject = entity->getTransform();

				TerrainMesh* mesh = entity->getMesh();
				size_t cellsCount = mesh->getCellsCount();

				for (size_t i = 0; i < cellsCount; i++)
				{
					TerrainCell* cell = mesh->getCell(i);

					BoundingFrustum frustum = *m_camera->getFrustum();
					BoundingBox aabb = *cell->getBoundingBox();

					ContainmentType conType = frustum.Contains(aabb);

					printf("%d\n", conType);

					cell->isVisible(conType != ContainmentType::DISJOINT);

					if (cell->isVisible())
					{
						cell->getRenderData()->updateConstantBuffer<EShaderType::ST_Vertex>(0, cbPerObject);
						cell->getRenderData()->updateConstantBuffer<EShaderType::ST_Vertex>(1, cbCamera);
						cell->getRenderData()->updateConstantBuffer<EShaderType::ST_Pixel>(0, cbPerFrame);
					}
				}
			}
		}
	}
	void Scene::updateStatic()
	{
		for (vector<Entity*>::const_iterator it = sceneStaticEntities.begin(); it != sceneStaticEntities.end(); ++it)
		{
			Entity *entity = (*it);
			if (entity)
			{
				entity->update(m_camera->getViewMatrix(), m_render->getProjectMatrix());

				CBPerObject *cbPerObject = entity->getTransform();
				SMaterial material = entity->getMesh()->getMaterial(0)->getAttributes();

				entity->getMesh()->getRenderData()->updateConstantBuffer<EShaderType::ST_Vertex>(0, cbPerObject);
				entity->getMesh()->getRenderData()->updateConstantBuffer<EShaderType::ST_Vertex>(1, cbCamera);
				entity->getMesh()->getRenderData()->updateConstantBuffer<EShaderType::ST_Pixel>(0, cbPerFrame);
			}
		}
	}
}
