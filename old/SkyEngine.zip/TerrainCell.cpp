#include "stdafx.h"
#include "TerrainCell.h"
#include "globals.h"

namespace sky
{
	TerrainCell::TerrainCell() :
		renderData(nullptr),
		m_vertexCount(0),
		m_indexCount(0),
		m_visible(false)
	{
	}

	TerrainCell::~TerrainCell()
	{
		if (renderData)
		{
			delete renderData;
			renderData = nullptr;
		}
	}

	bool TerrainCell::init(vector<StaticMeshVertex>& verticess, size_t nodeIndexX, size_t nodeIndexY, size_t cellHeight, size_t cellWidth, int terrainWidth)
	{
		m_vertexCount = cellHeight * cellWidth;
		m_indexCount = (cellHeight - 1) * (cellWidth - 1) * 6;

		vector<StaticMeshVertex> vertices;
		vector<unsigned int> indices(m_indexCount);

		int cellVertexIndex = (nodeIndexX * (cellWidth - 1)) + (nodeIndexY * (cellHeight - 1) * (terrainWidth - 1));

		float maxX = FLT_MIN;
		float minX = FLT_MAX;
		float maxY = FLT_MIN;
		float minY = FLT_MAX;
		float maxZ = FLT_MIN;
		float minZ = FLT_MAX;

		for (size_t j = 0; j< cellHeight; j++)
		{
			for (size_t i = 0; i< cellWidth; i++)
			{
				StaticMeshVertex vertex = verticess[cellVertexIndex];

				float x = vertex.position.x;
				float y = vertex.position.y;
				float z = vertex.position.z;

				if (x > maxX)  maxX = x;
				if (x < minX)  minX = x;
				if (y > maxY)  maxY = y;
				if (y < minY)  minY = y;
				if (z > maxZ)  maxZ = z;
				if (z < minZ)  minZ = z;

				vertices.push_back(vertex);
				cellVertexIndex++;
			}
			cellVertexIndex += terrainWidth - cellWidth;
		}

		int k = 0;
		for (DWORD i = 0; i < cellHeight - 1; i++)
		{
			for (DWORD j = 0; j < cellWidth - 1; j++)
			{
				indices[k] = i*cellWidth + j;

				indices[k + 1] = i*cellWidth + j + 1;

				indices[k + 2] = (i + 1)*cellWidth + j;


				indices[k + 3] = (i + 1)*cellWidth + j;

				indices[k + 4] = i*cellWidth + j + 1;

				indices[k + 5] = (i + 1)*cellWidth + j + 1;

				k += 6; // next quad
			}
		}

		XMFLOAT3 bbCenter = XMFLOAT3((maxX - minX) / 2, (maxY - minY) / 2, (maxZ - minZ) / 2);
		XMFLOAT3 extents = XMFLOAT3(cellWidth - 1, maxY - minY, cellHeight - 1);

		m_AABB = BoundingBox(bbCenter, extents);

		StaticMeshVertexBuffer *VertexBuffer = new StaticMeshVertexBuffer();
		VertexBuffer->init(vertices);

		StaticIndexBuffer *indices_buffer = new StaticIndexBuffer();
		indices_buffer->init(indices);

		StaticMeshResources *meshResources = new StaticMeshResources(VertexBuffer, indices_buffer);

		renderData = new StaticMeshRenderData();

		ShaderManager *shaderManager = global::getShaderManager();

		assert(shaderManager != nullptr);

		IVertexShader *vertexShader = shaderManager->getVertexShader(EVertexShader::VS_TERRAIN);

		IPixelShader *pixelShader = shaderManager->getPixelShader(EPixelShader::PS_TERRAIN);

		renderData->setResources(meshResources, vertexShader, pixelShader);

		return true;
	}

	StaticMeshRenderData* TerrainCell::getRenderData() const
	{
		return renderData;
	}

	void TerrainCell::isVisible(bool visible)
	{
		m_visible = visible;
	}

	bool TerrainCell::isVisible() const
	{
		return m_visible;
	}

	const BoundingBox *TerrainCell::getBoundingBox() const
	{
		return &m_AABB;
	}
}
